# f21sc-2021-22-hello-world

C# hello world program


Start a project in Visual Studio (or other IDE you are using), create a project and load this file into it.
Then select 'Build' and then 'Run' in the GUI

Or, from the command-line (either on Linux or WSL in Windows) compile and run like this
> mcs -out:hello.exe hello.cs

> mono ./hello.exe

and you should see this message
> Hello World!
 
