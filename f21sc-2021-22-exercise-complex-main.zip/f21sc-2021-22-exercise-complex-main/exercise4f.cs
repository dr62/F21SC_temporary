// Exercise 4f from Lecture 3 on C# Classes and Objects
// For arithmetic see: https://en.wikipedia.org/wiki/Complex_number#Addition_and_subtraction
// See Wolfram Alpha for a calculator: https://www.wolframalpha.com/examples/mathematics/numbers/complex-numbers/
// or directly here: https://www.wolframalpha.com/widgets/gallery/view.jsp?id=4500e4037738e13c0c18db508e18d483
//
// Note: results from the calculator might differ by bringing numbers into normal form.
//       you don't need to do this in your implementation, and that test cases assume that you don't.
// Beware: implementation of division is more complicated, and doesn't yield just a complex number in itself;
//         you can omit implementation of division (but note that tests will fail in this case)
// ----------------------------------------------------------------------------------------------------------------

using System;

public class Tester {

  public struct Complex {
    // *** COMPLETE THIS CODE ***
    // define field or properties for the 'Real' and the 'Imag' component of a complext number
    
    // constructor with initialisation
    public Complex (int r, int i) {
      this.Real = r;
      this.Imag = i;
    }

    public override string ToString() {
      return this.Real.ToString()+"+"+this.Imag.ToString()+"i";
    }

    // uses operator overloading to redefine infix +
    public static Complex operator+ (Complex a, Complex b) 
    {
      // *** COMPLETE THIS CODE ***
    }
    // uses operator overloading to redefine infix -
    public static Complex operator- (Complex a, Complex b) 
    {
      // *** COMPLETE THIS CODE ***
    }
    // uses operator overloading to redefine infix *
    public static Complex operator* (Complex a, Complex b) 
    {
      // *** COMPLETE THIS CODE ***
    }
    // uses operator overloading to redefine infix /
    public static Complex operator/ (Complex a, Complex b) 
    {
      // *** COMPLETE THIS CODE ***
    }
    // NO: we can't use overloading for / if real and imag parts are over ints
    // public static Complex operator/ (Complex a, Complex b) 
  }

  // aux fct  
  public static int sqr (int x) { 
    return x*x;
  }

  // We need to use a modified interface like this, additionally returning the reciprocal part of the number
  // Hint: use the constructore 'Tuple', just like 'Complex', to construct the return structure
  public static Tuple<int,Complex> div_complex(Complex a, Complex b) 
  {
      // *** COMPLETE THIS CODE ***
  }

  // Main fct for testing  
  public static void Main (string []args) {
     if (args.Length != 4) { // expect 4 args: r1 i1 r2 i2
       System.Console.WriteLine("Usage: exercise4f <int> <int> <int> <int>");
     } else {
       int r1 = Convert.ToInt32(args[0]);
       int i1 = Convert.ToInt32(args[1]);
       int r2 = Convert.ToInt32(args[2]);
       int i2 = Convert.ToInt32(args[3]);
       Complex c1 = new Complex(r1,i1);
       Complex c2 = new Complex(r2,i2);
       Tuple<int, Complex> d;
       System.Console.WriteLine("Complex addition: {0} + {1} = {2}", c1, c2, c1+c2);
       System.Console.WriteLine("Complex subtraction: {0} - {1} = {2}", c1, c2, c1-c2);
       System.Console.WriteLine("Complex multiplication: {0} * {1} = {2}", c1, c2, c1*c2);
       // System.Console.WriteLine("Complex division: {0} / {1} = {2}", c1, c2, c1/c2);
       d = div_complex(c1, c2);
       System.Console.WriteLine("Complex division: {0} / {1} = 1/{2} * {3}", c1, c2, d.Item1, d.Item2);
     }
  }

}
