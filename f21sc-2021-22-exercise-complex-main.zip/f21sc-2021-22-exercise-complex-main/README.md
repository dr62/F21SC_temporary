# f21sc-2021-22-exercise-complex

Exercise about basic arithmetic over complex numbers in C#

**Fork** and **Clone** this repo using the gitlab web interface. Then work in the local folder
that you get from cloning the project. Once finished coding, upload a version through your IDE,
or **Add** files, **Commit** changes, and **Push** everything using git from the commandline.
Once uploaded, the gitlab continuous integration (CI) engine will run automated tests, and will
report wether these tests have been successful or not.

Complete the code `exercise4f.cs`.
Use the given test wrapper in `Main()` to run the code.
Use the script `test.sh` to run automated tests (this is triggered automatically when uploading a version to gitlab).

To read up on complex numbers check this Wikipedia page: [https://en.wikipedia.org/wiki/Complex_number#Addition_and_subtraction]

Build the entire code:
> make all

Run one test case:
> make run

Run all test cases:
> make test

or
> sh ./test.sh

