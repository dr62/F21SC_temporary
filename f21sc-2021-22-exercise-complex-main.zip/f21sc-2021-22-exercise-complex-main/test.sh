#!/bin/bash

# function to check output from running $cmd against expected output
check () {
    #echo "Cmd: $cmd"
    echo "Output: \n$out"
    echo "Expected: \n$exp"
    if [ "$out" = "$exp" ]
    then echo ".. OK"
	 ok=$(( $ok + 1))
    else echo "** WRONG"
	 ret=1
    fi
    n=$(( $n + 1))
}

# name of the application to run
prg=exercise4f
# return code; 0 = ok, anything else is an error
ret=0
ok=0
n=0

# -------------------------------------------------------
# a sequence of unit tests

out="`mono ./${prg}.exe 3 13 7 17`"
# echo "$out"
exp=$(cat <<EOS
Complex addition: 3+13i + 7+17i = 10+30i
Complex subtraction: 3+13i - 7+17i = -4+-4i
Complex multiplication: 3+13i * 7+17i = -200+142i
Complex division: 3+13i / 7+17i = 1/338 * 242+40i
EOS
)
check

out="`mono ./${prg}.exe 2 3 4 5`"
# echo "$out"
exp=$(cat <<EOS
Complex addition: 2+3i + 4+5i = 6+8i
Complex subtraction: 2+3i - 4+5i = -2+-2i
Complex multiplication: 2+3i * 4+5i = -7+22i
Complex division: 2+3i / 4+5i = 1/41 * 23+2i
EOS
)
check

out="`mono ./${prg}.exe 5 -1 3 7`"
# echo "$out"
exp=$(cat <<EOS
Complex addition: 5+-1i + 3+7i = 8+6i
Complex subtraction: 5+-1i - 3+7i = 2+-8i
Complex multiplication: 5+-1i * 3+7i = 22+32i
Complex division: 5+-1i / 3+7i = 1/58 * 8+-38i
EOS
)
check

out="`mono ./${prg}.exe 0 1 1 0`"
# echo "$out"
exp=$(cat <<EOS
Complex addition: 0+1i + 1+0i = 1+1i
Complex subtraction: 0+1i - 1+0i = -1+1i
Complex multiplication: 0+1i * 1+0i = 0+1i
Complex division: 0+1i / 1+0i = 1/1 * 0+1i
EOS
)
check


# return status code (0 for ok, 1 for not)
echo "$ok of $n tests are OK"
exit $ret
