# f21sc-2021-22-fundamentals

Several simple test programs from the C# Fundamentals section:
- enums sample: use of enumeration type
- double sample: calling a method in another class
- command-line input sample (based on double): example of reading input from the command-line 
- loops sample: several examples of loops
- array samples: several examples of operations on arrays
- nullable types: use of nullable types
- functions samples: use of (local) methods/functions

See the slide for the C# Fundamentals part: [http://www.macs.hw.ac.uk/~hwloidl/Courses/F21SC/Csharp_Fundamentals_4up.pdf]

See these 3 lecture captures discussing these slides:
- [https://web.microsoftstream.com/video/0697d85e-e01e-4a99-a8ed-d8492778a5d1]
- [https://web.microsoftstream.com/video/60b46673-36b6-4d9d-917e-380932f47d2d]
- [https://web.microsoftstream.com/video/6d7bdb8c-0fe7-4b32-be12-dd0f9d75bf22]

The labsheet with exercises on C# Fundamentals is here: [http://www.macs.hw.ac.uk/~hwloidl/Courses/F21SC/LabSheetCsharpFundamentals.pdf]

A tutorial capture discussing the exercises is here:
- [https://web.microsoftstream.com/video/b8d54364-6c76-487d-98a5-7732cbde9d6f]