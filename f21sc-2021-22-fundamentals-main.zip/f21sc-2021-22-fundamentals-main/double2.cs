// Hello-world-like example program

using System;

class TestClass {
  public static int Double(int val) {
    return val*2;
  }

  public static void Main(string []args) {
     if (args.Length != 1) { // expect 1 arg: value to double
       System.Console.WriteLine("Provide an int value as argument");
     } else {    
       int x = Convert.ToInt32(args[0]);
       System.Console.WriteLine("{0}*2 = {1}", x, TestClass.Double(x));
     }
  }
}
