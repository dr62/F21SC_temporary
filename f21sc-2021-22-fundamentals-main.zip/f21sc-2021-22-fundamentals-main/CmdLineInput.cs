// From Java to C#: Sec 5.1.1
// Compile: mcs CmdLineInput.cs
// Run:     mono CmdLineInput.exe 12
// -----------------------------------------------------------------------------

using System;

class TestClass {
  public static void Main (string []args) {
     if (args.Length != 1) { // expect 1 args: x
       System.Console.WriteLine("Usage: hello1.cs <int>");
     } else {
       int x = Convert.ToInt32(args[0]);
       MyClass m = new MyClass();
       System.Console.WriteLine("Doubling the value {0} gives {1}", x, m.Double(x));
     }
  }
}

class MyClass {
  public int Double(int val) {
    return val*2;
  }
}
