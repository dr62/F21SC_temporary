/*
  Exercise: implement matrix multiplication 
  See: https://en.wikipedia.org/wiki/Matrix_multiplication#Illustration

  For testing, hard-code several matrices directly into the main method.
*/

public class Matrix {

  // -----------------------------------------------------------------------------
  // The main fct to implement  
  // -----------------------------------------------------------------------------
  public static int[,] MatMult (int[,] m1, int [,] m2) {
    // *** COMPLETE THIS CODE ***
    // Hint: use .Rank to get the dimensions of the matrix, and .GetLenth(0) the size in dimension 0 etc
    //       implement the structure of the code as in the Wikipedia page above
    //       expect to use 3 nested loops, and store/return the result in a new matrix
  }

  // -----------------------------------------------------------------------------
  // Auc fcts  
  // -----------------------------------------------------------------------------
  // Turn a matrix into a string
  public static string ToString(int[,] m1) {
    int r = m1.Rank;
    if (r != 2) {
      System.Console.WriteLine("Expecting a 2-dim matrix");
      return null; // Better: use an exception here
    }
    int m = m1.GetLength(0); // no. of rows in m1
    int n = m1.GetLength(1); // no. of cols in m1
    string str = "" ;
    for (int i = 0; i < m; i++) {
      str = str + "[";
      for (int j = 0; j < n; j++) {
	if (j>0) { str = str +   ","; }
	str = str + m1[i,j].ToString();
      }
      str = str + "]\n";
    }
    return str;
  }

  // -----------------------------------------------------------------------------
    
  public static void Main() {
    int[,] m1 = new int[3,3] { {1,2,3}, {1,2,3}, {1,2,3} };
    int[,] m2 = new int[3,3] { {1,2,3}, {1,2,3}, {1,2,3} };
    int[,] m3 = Matrix.MatMult(m1,m2);
    System.Console.WriteLine("First Matrix:\n{0}", Matrix.ToString(m1));
    System.Console.WriteLine("Second Matrix:\n{0}", Matrix.ToString(m2));
    System.Console.WriteLine("Result of Matrix Multiplication:\n{0}", Matrix.ToString(m3));
    int[,] m4 = new int[2,3] { {1,2,3}, {7,3,4} };
    int[,] m5 = new int[3,3] { {5,2,1}, {7,2,1}, {4,2,8} };
    int[,] m6 = Matrix.MatMult(m4,m5);
    System.Console.WriteLine("First Matrix:\n{0}", Matrix.ToString(m4));
    System.Console.WriteLine("Second Matrix:\n{0}", Matrix.ToString(m5));
    System.Console.WriteLine("Result of Matrix Multiplication:\n{0}", Matrix.ToString(m6));
    int[,] m04 = new int[2,3] { {1,2,1}, {7,3,9} };
    int[,] m05 = new int[3,3] { {6,0,2}, {4,1,8}, {3,2,0} };
    int[,] m06 = Matrix.MatMult(m04,m05);
    if (m06 == null) {
      System.Console.WriteLine("Result of multiplication is undefined\n");
    }
    System.Console.WriteLine("First Matrix:\n{0}", Matrix.ToString(m04));
    System.Console.WriteLine("Second Matrix:\n{0}", Matrix.ToString(m05));
    System.Console.WriteLine("Result of Matrix Multiplication:\n{0}", Matrix.ToString(m06));
    int[,] m7 = new int[2,3] { {1,2,3}, {7,3,4} };
    int[,] m8 = new int[3,3] { {5,2,1}, {7,2,1}, {4,2,8} };
    int[,] m9 = Matrix.MatMult(m7,m8);
    if (m9 == null) {
      System.Console.WriteLine("Result of multiplication is undefined\n");
    }
    System.Console.WriteLine("First Matrix:\n{0}", Matrix.ToString(m7));
    System.Console.WriteLine("Second Matrix:\n{0}", Matrix.ToString(m8));
    System.Console.WriteLine("Result of Matrix Multiplication:\n{0}", Matrix.ToString(m9));
    /*
    int[] m07 = new int[2] { 1,2 };
    int[] m08 = new int[3] { 5,2,1 };
    int[] m09 = Matrix.MatMult(m07,m08);
    if (m09 == null) {
      System.Console.WriteLine("Result of multiplication is undefined\n");
    } 
    */
  }
}

/* Expect these results:
  [ [ 6, 12, 18 ]
    [ 6, 12, 18 ]
    [ 6, 12, 18 ] ]

  [ [ 31, 12, 27 ]
    [ 72, 28, 42 ] ]
*/
