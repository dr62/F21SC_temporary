// Very basic C# exercises
// See lab sheet on C# Fundamentals: http://www.macs.hw.ac.uk/~hwloidl/Courses/F21SC/LabSheetCsharpFundamentals.pdf
// Exercise: implement a NextDay() and a WhatDay() medthod

namespace Exercise0 {

// we need this to for example write, using System.Console.WriteLine
using System;

// we use just one class for now
class Enums  {
   // this defines a new type, with name Weekdays, and lists possible values
   enum Weekdays { Mon, Tue, Wed, Thu, Fri, Sat, Sun };
   // this defines another type, to distinguish weekdays; we will use it later
   // *** COMPLETE THIS CODE *** you need to define an enumeration Weekdays, with element WeekDay and WeekEnd

   // a standard main function, that takes arguments from the command-line 
   static void Main(string []args) {
     //System.Console.WriteLine("cmdline arg: {0}", args[0]);
     if (args.Length != 1) { // expect 1 arg: day of week
       System.Console.WriteLine("Usage: exercise0 <weekday>");
     } else {
       Weekdays z = Weekdays.Mon; // needed for parsing
       Weekdays d = (Weekdays)Enum.Parse(z.GetType(), args[0]);
       Enums.Test(d); // call the test method in this class
       // Enums.Test(Weekdays.Sun); // test with a fixed input
     }
   }
   /// <summary>
   /// This method runs series of tests on the methods in this class.
   /// </summary>
   /// <seealso cref="NextDay(Weekdays)"> This is the main method that is tested. </seealso>
   static void Test(Weekdays d) {
      Days d0 = Enums.WhatDay(d);
      System.Console.WriteLine("Testing some enums now...");
      Weekdays e = Enums.NextDay(d);
      Days e0 = Enums.WhatDay(e);
      System.Console.WriteLine("Tomorrow of "+d+" (a "+d0+") is "+e+" (a "+e0+")");
      /*
      Weekdays f = Enums.NextDay1(d);
      Days f0 = Enums.WhatDay(f);
      System.Console.WriteLine("Tomorrow of "+d+" (a "+d0+") is "+f+" (a "+f0+")");
      */
   }

   // We want to define a method that takes a day and returns the next day
   /// <summary>
   /// Take a day as input and return the next day as a result.
   /// </summary>
   /// <param name="d"> The input day  </param>
   /// <returns>Returns the next day of the week. </returns>
   static Weekdays NextDay(Weekdays d) {
     // *** COMPLETE THIS CODE ***
     // Note: there is one straightforwar but verbose and one shorter version; try both
   }


   /// <summary>
   /// Take a day as input and return whether it is a WeekDay or a WeekEnd.
   /// </summary>
   /// <param name="d"> The input day  </param>
   /// <returns>Returns WeekDay or WeekEnd. </returns>
   static Days WhatDay(Weekdays d) {
     // *** COMPLETE THIS CODE ***
     // Note: there is one straightforwar but verbose and one shorter version; try both
   }
} /* class */
} /* namespace */
