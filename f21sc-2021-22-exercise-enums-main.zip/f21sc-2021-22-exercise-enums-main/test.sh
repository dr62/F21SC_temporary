#!/bin/bash

# function to check output from running $cmd against expected output
check () {
    #echo "Cmd: $cmd"
    echo "Output: \n$out"
    echo "Expected: \n$exp"
    if [ "$out" = "$exp" ]
    then echo ".. OK"
	 ok=$(( $ok + 1))
    else echo "** WRONG"
	 ret=1
    fi
    n=$(( $n + 1))
}

# name of the application to run
prg=enums
# return code; 0 = ok, anything else is an error
ret=0
ok=0
n=0

# -------------------------------------------------------
# a sequence of unit tests

out="`mono ./${prg}.exe Tue`"
# echo "$out"
exp=$(cat <<EOS
Testing some enums now...
Tomorrow of Tue (a WeekDay) is Wed (a WeekDay)
EOS
)
check

out="`mono ./${prg}.exe Sun`"
# echo "$out"
exp=$(cat <<EOS
Testing some enums now...
Tomorrow of Sun (a WeekEnd) is Mon (a WeekDay)
EOS
)
check


# return status code (0 for ok, 1 for not)
echo "$ok of $n tests are OK"
exit $ret
